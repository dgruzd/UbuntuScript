#!/usr/bin/env python

from bluez.Manager import Manager
import glib
import sys
import os
import signal

def handler(signum, frame):
	print
	os._exit(1)

signal.signal(signal.SIGINT, handler)
signal.signal(signal.SIGTERM, handler)

class Main:

	def __init__(self):
		self.manager = Manager("gobject")
		self.adapter = self.manager.GetAdapter()
		
		self.adapter.HandleSignal(self.on_device_discovered, "DeviceFound")
		self.adapter.HandleSignal(self.on_property_changed, "PropertyChanged")
		
		self.adapter.StartDiscovery()
		print "Please HOLD the START and ENTER buttons on the PS3 remote."
		print "Searching for devices, please wait..."
		
		self.discovered_devices = {}
		self.loop = glib.MainLoop()
		self.loop.run()
		
		
	def on_device_discovered(self, address, values):
		if not address in self.discovered_devices:
			self.discovered_devices[address] = values
			

	def on_property_changed(self, key, value):
		if key == "Discovering":
			if not value:
				self.adapter.StopDiscovery()
				id = 1
				ps3 = 1
				print "Found:"
				if len(self.discovered_devices) == 0:
					print "No devices found"
					os._exit(1)
				
				for dev, values in self.discovered_devices.iteritems():
					if "Name" not in values:
						values["Name"] = "Unknown"
					
					if values["Name"] == "BD Remote Control":
						ps3 = id
					print "%d: %s [%s]" % (id, dev, values["Name"])
					id += 1
				
				while(1):	
					print "Select the device you wish to add [%d]: " % ps3,
					entry = sys.stdin.readline()
					entry = entry.strip(" \r\n")

					try:
						if len(entry) == 0:
							entry = ps3
						else:
							entry = int(entry)

						dev = self.discovered_devices.items()[entry-1]

						print "Deregistering device... ",
						sys.stdout.flush()
						try:
							dev = self.adapter.FindDevice(dev[0])
							self.adapter.RemoveDevice(dev)
							print "Done"
						except Exception, e:
							print "Failed (", e, ")"
							os._exit(1)
						finally:
							os._exit(0)
						
						break
					except Exception, e:
						print "Invalid entry selected"
						continue
		
Main()
